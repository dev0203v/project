﻿using System.Windows;
using LiveCharts;
using Resource_Monitoring.Models;
using static Resource_Monitoring.Models.Memory;

namespace Resource_Monitoring
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        public ChartValues<int> C_Chart { get; set; }
        public ChartValues<double> M_Chart { get; set; }
        public ChartValues<double> P_Chart { get; set; }
        public ChartValues<int> D_Chart { get; set; }

        public int cpuvalue;
        public double memvalue;
        public double porcvalue;
        public int diskvalue;

        DB db = new DB();

        public MainWindow()
        {
            InitializeComponent();
            ResourceData();

            C_Chart = new ChartValues<int>();
            M_Chart = new ChartValues<double>();
            P_Chart = new ChartValues<double>();
            D_Chart = new ChartValues<int>();

            Chart_proc.DataContext = this;
        }
        public async void ResourceData()
        {
            while (true)
            {
                await Task.Delay(1000);

                cpuvalue = await UsageInfo.GetTotalCpuUsage();
                memvalue = await UsageInfo.GetMemValue();
                porcvalue = await UsageInfo.GetProcessCpuUsage();
                diskvalue = Convert.ToInt32(UsageInfo.GetHddUsage().Usage);

                await Dispatcher.BeginInvoke(() =>
                {
                    C_Chart.Add((int)cpuvalue);
                    cpuga.Value = cpuvalue;
                });
                await Dispatcher.BeginInvoke(() =>
                {
                    M_Chart.Add((double)memvalue);
                    memga.Value = memvalue;
                });
                await Dispatcher.BeginInvoke(() =>
                {
                    P_Chart.Add((double)porcvalue);
                    procga.Value = porcvalue;
                });
                await Dispatcher.BeginInvoke(() =>
                {
                    D_Chart.Add((int)diskvalue);
                    hddga.Value = diskvalue;
                });
            }
        }
        private async void Window_Activated(object sender, EventArgs e)
        {
            while (true)
            {
                await Task.Delay(10000);
                string query = "INSERT INTO monitoring_log VALUE(NOW(), " + cpuvalue + "," + memvalue + "," + porcvalue + "," +diskvalue + ");";
                DB.ExecuteMySQLQuery(query, db);
            }
        }
    }
}






