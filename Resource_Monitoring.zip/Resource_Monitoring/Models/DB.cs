﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows;

namespace Resource_Monitoring.Models
{
    public class DB
    {

        private  string ip;
        private int port;
        private string uid;
        private string pwd;
        private string dbname;
        private string connectString;
        MySqlConnection conn;


        public DB()
        {
            // CharSet=utf8 설정을 안하면 한글 입출력시 물음표(?)로 인식
            // ip = "127.0.0.1";
            ip = "localhost";
            port = 3306;
            uid = "MINA";
            pwd = "1234";
            dbname = "resource";
            connectString = $"Server={ip};Port={port};Database={dbname};Uid={uid};Pwd={pwd};CharSet=utf8;";
            conn = new MySqlConnection(connectString);  // DB 설정

        }


        public  bool CloseConnection()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch (MySqlException e)
            {
                MessageBox.Show(e.Message);
                return false;
            }
        }


        public static async void ExecuteMySQLQuery(string userQuery, DB db)
        {
            
            try
            {
                db.conn.Open();
                db.conn.Ping();
                string query = userQuery;
                MySqlCommand cmd = new MySqlCommand(query, db.conn);
                
                cmd.ExecuteNonQuery();
                db.conn.Close();

            }
            catch (MySqlException e)
            {
                MessageBox.Show(e.Message);
            }

        }
    }
}

